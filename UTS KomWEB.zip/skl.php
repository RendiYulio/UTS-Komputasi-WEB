<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rendi Yulio Pramudita</title>

    <style>
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
        background: rgb(0,0,0);
        background: linear-gradient(0deg, rgba(0,0,0,1) 27%, rgba(255,255,255,1) 100%);;
    }

    nav {
        background-color: #121414;
        padding: 15px 0;
        text-align: center;
    }

    nav a {
        margin: 0 15px;
        color: #ece3d8;
        text-decoration: none;
        font-size: 1.1em;
    }

    nav a:hover {
        color: #909984;
    }

    .container {
        display: flex;
        flex-direction: column;
        align-items: flex-start;
        padding: 50px;
    }

    .content-section {
        display: flex;
        flex-direction: row;
        justify-content: space-between;
        align-items: flex-start;
        width: 100%;
        margin-bottom: 50px;
    }

    .image-section {
        flex: 1;
        padding-right: 20px;
    }

    .text-section {
        flex: 2;
        text-align: left;
    }

    .image-section img {
        max-width: 73%;
        height: auto;
        border-radius: 10px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    }

    h1 {
        font-family: 'Abril Fatface', serif;
        font-weight: bold;
        font-size: 2.2em;
        color: #ffffff;
    }

    p {
        font-size: 1em;
        color: #ffffff;
        margin: 10px 0;
    }

    figcaption {
        margin-top: 5px;
        font-size: 0.9em;
        color: #ffffff;
        text-align: center;
    }

    .section-sk1 {
        margin-bottom: 40px;
    }

    .section-sk2 {
        margin-top: 40px;
    }

    </style>

</head>
<body>
    <nav>
        <a href="home.php">Home</a>
        <a href="about.php">About</a>
        <a href="project.php">Project</a>
        <a href="skl.php">Skills</a>
        <a href="teman.php">Daftra Teman</a>
    </nav>

    <div class="container">
        <!-- Section untuk gambar pertama dan teks pertama -->
        <div class="content-section section-sk1">
            <div class="image-section">
                <img src="sskk.jpg" alt="Sertifikat BNSP" class="sk1-image">
            </div>
            <div class="text-section">
                <?php
                include("koneksi.php");
                // Query untuk mengambil data dari tabel "skill"
                $sql = "SELECT * FROM skil";
                $hasil = mysqli_query($koneksi, $sql);

                // Cek apakah query berhasil
                if (!$hasil) {
                    die("Query gagal: " . mysqli_error($koneksi));
                }

                // Cek apakah ada data
                if (mysqli_num_rows($hasil) > 0) {
                    $row = mysqli_fetch_assoc($hasil); // Ambil data baris pertama jika ada
                } else {
                    $row = []; // Jika tidak ada data, set array kosong
                }

                mysqli_close($koneksi);
                ?>
                <h1><?= isset($row["judul1"]) ? $row["judul1"] : ''; ?></h1>
                <p><?= isset($row["des1"]) ? $row["des1"] : ''; ?></p>
            </div>
        </div>

        <!-- Section untuk gambar kedua dan teks kedua -->
        <div class="content-section section-sk2">
            <div class="image-section">
                <img src="sskk2.jpg" alt="Sertifikat UI/UX figma" class="sk2-image">
            </div>
            <div class="text-section">
                <h1><?= isset($row["judul2"]) ? $row["judul2"] : ''; ?></h1>
                <p><?= isset($row["des2"]) ? $row["des2"] : ''; ?></p>
            </div>
        </div>
    </div>
</body>
</html>