<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rendi Yulio Pramudita</title>

<style>
body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background: rgb(0,0,0);
    background: radial-gradient(circle, rgba(0,0,0,1) 0%, rgba(255,255,255,1) 100%);
}

nav {
    background-color: #121414;
    padding: 15px 0;
    text-align: center;
}

nav a {
    margin: 0 15px;
    color: #ece3d8;
    text-decoration: none;
    font-size: 1.1em;
}

nav a:hover {
    color: #909984;
}

.container {
    text-align: center;
    padding: 50px;
}

.text-section {
    margin-top: 20px;
}

.profile-image {
    border-radius: 50%;
    width: 150px;
    height: 150px;
    border: 5px solid #121414;
    display: block;
    margin: 0 auto; /* Center the image */
}

h1 {
    font-family: 'Abril Fatface', serif;
    font-size: 2.5em;
    color: #ffffff;
}

h2 {
    font-family: 'Abril Fatface', serif;
    font-size: 1.8em;
    color: #ffffff;
}

p {
    font-size: 1.2em;
    color: #ffffff;
    max-width: 700px;
    margin: 20px auto;
}

</style>

</head>
<body>
    <nav>
        <a href="home.php">Home</a>
        <a href="about.php">About</a>
        <a href="project.php">Project</a>
        <a href="skl.php">Skills</a>
        <a href="teman.php">Daftra Teman</a>
    </nav>
    
    <div class="container">
        <img src="kepala rendi.jpg" alt="Rendi Yulio Pramudita" class="profile-image">
        <div class="text-section">
            <?php
            include("koneksi.php");
            // Query untuk mengambil data dari tabel "home_db"
            $sql = "SELECT * FROM home_db";
            $hasil = mysqli_query($koneksi, $sql);

            // Cek apakah query berhasil
            if (!$hasil) {
                die("Query gagal: " . mysqli_error($koneksi));
            }

            // Cek apakah ada data
            if (mysqli_num_rows($hasil) > 0) {
                $row = mysqli_fetch_assoc($hasil); // Ambil data baris pertama jika ada
            } else {
                $row = []; // Jika tidak ada data, set array kosong
            }

            // Menutup koneksi
            mysqli_close($koneksi);
            ?>

            <h1><?= isset($row["title"]) ? $row["title"] : ''; ?></h1>
            <h2><?= isset($row["bwh"]) ? $row["bwh"] : ''; ?></h2>
            <p><?= isset($row["description"]) ? $row["description"] : 'Tidak ada data.'; ?></p>
        </div>
    </div>
</body>
</html>
