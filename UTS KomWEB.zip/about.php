<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rendi Yulio Pramudita - Portfolio</title>

<style>
body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background: rgb(0,0,0);
    background: linear-gradient(90deg, rgba(0,0,0,1) 54%, rgba(166,194,239,1) 100%, rgba(252,252,252,1) 100%);
}

nav {
    background-color: #121414;
    padding: 15px 0;
    text-align: center;
}

nav a {
    margin: 0 15px;
    color: #ece3d8;
    text-decoration: none;
    font-size: 1.1em;
}

nav a:hover {
    color: #909984;
}

.container {
    display: flex;
    align-items: flex-start; 
    padding: 50px;
}

.text-section {
    flex: 2; 
}

.abut-image {
    flex: 1; 
    max-width: 29%;
    height: auto;
    border-radius: 10px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
    margin-left: 20px; 
}

h1 {
    font-family: 'Abril Fatface', serif;;
    font-weight: bold;
    font-size: 2.5em;
    color: #9FBAE6;
    margin-top: 0;
}

h2 {
    font-family: 'Abril Fatface', serif;
    font-size: 1.8em;
    color: #9FBAE6; 
}

p {
    font-size: 1em;
    color: #ffffff;
    margin: 10px 0;
    text-indent: 40px;
    text-align: justify;
}

ul {
    list-style-type: disc;
    padding-left: 20px;
    color: #ffffff;
}

ul li {
    font-size: 1em;
    margin-bottom: 10px;
}

</style>

</head>
<body>
    <nav>
        <a href="home.php">Home</a>
        <a href="about.php">About</a>
        <a href="project.php">Project</a>
        <a href="skl.php">Skills</a>
        <a href="teman.php">Daftra Teman</a>
    </nav>
    
    <div class="container">
        <div class="text-section">
            <?php
            include("koneksi.php");
            // Query untuk mengambil data dari tabel "about_db"
            $sql = "SELECT * FROM about_db";
            $hasil = mysqli_query($koneksi, $sql);

            // Cek apakah query berhasil
            if (!$hasil) {
                die("Query gagal: " . mysqli_error($koneksi));
            }

            // Cek apakah ada data
            if (mysqli_num_rows($hasil) > 0) {
                $row = mysqli_fetch_assoc($hasil); // Ambil data baris pertama jika ada
            } else {
                $row = []; // Jika tidak ada data, set array kosong
            }

            // Menutup koneksi
            mysqli_close($koneksi);
            ?>

<div class="container content-section">
    <div class="row">
        <div class="col-sm-3">
            <h1><?= isset($row["salam"]) ? $row["salam"] : ''; ?></h1>
        </div>
        <div class="col-sm-3">
            <p><?= isset($row["perkenalan"]) ? $row["perkenalan"] : ''; ?></p>
        </div>
        <div class="col-sm-3">
            <p><?= isset($row["pekenalan lagi"]) ? $row["pekenalan lagi"] : 'Tidak ada data.'; ?></p>
        </div>
        <div class="col-sm-3">
            <h2><?= isset($row["kontak gede"]) ? $row["kontak gede"] : 'Tidak ada data.'; ?></h2>
        </div>
        <div class="col-sm-3">
          <ul>
        <li><strong>Nama Lengkap:</strong> <?= $row["nama"]; ?></li>
        <li><strong>Pendidikan Saat Ini:</strong> <?= $row["pendidikan_saat_ini"]; ?></li>
        <li><strong>Keterampilan:</strong> 
            <ul>
                <?php
                $keterampilan = explode(',', $row["keterampilan"]);
                foreach ($keterampilan as $skill) {
                    echo "<li>$skill</li>";
                }
                ?>
            </ul>
        </li>
        <li><strong>Minat:</strong> <?= $row["minat"]; ?></li>
        <li><strong>Kontak:</strong> <?= $row["kontak"]; ?></li>
        <li><strong>Alamat:</strong> <?= $row["alamat"]; ?></li>
    </ul>
        </div>
    </div>
</div>
        </div><img src="abut.jpg" alt="Rendi Yulio Pramudita" class="abut-image">
    </div>
       

</body>
</html>