<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css"
        integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N"
        crossorigin="anonymous">

<style>
body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background: rgb(18,20,20);
    background: linear-gradient(0deg, rgba(18,20,20,1) 0%, rgba(167,255,169,1) 100%);
}
nav {
    background-color: #121414;
    padding: 15px 0;
    text-align: center;
}

nav a {
    margin: 0 15px;
    color: #ece3d8;
    text-decoration: none;
    font-size: 1.1em;
}

nav a:hover {
        color: #909984;
}

.container {
    margin-top: 50px;
}

.btn-primary, .btn-warning, .btn-danger {
    font-size: 1.2rem;
}

.form-control {
    margin-bottom: 15px;
    background-color: rgba(255, 255, 255, 0.8); 
}

label {
    color: #ffffff;
}
        
table {
    color: white;
    width: 100%;
}
        
th, td {
    background-color: rgba(0, 0, 0, 0.5); 
    color: white; 
}
        
th {
    background-color: rgb(18, 20, 20); 
}

.btn-primary {
    background-color: #121414;
    border-color: #121414;
}

.btn-primary:hover {
    background-color: #0e0f0f;
    border-color: #0e0f0f;
}

h1 {
    color: #ffffff;
    font-weight: bold;
    font-family: 'Abril Fatface', serif;
}


</style>
    <title>Teman saya!</title>
</head>

<body>
<nav>
    <a href="home.php">Home</a>
    <a href="about.php">About</a>
    <a href="project.php">Project</a>
    <a href="skl.php">Skills</a>
    <a href="teman.php">Daftra Teman</a>
</nav>

<?php
include("koneksi.php");
// Inisialisasi variabel untuk menyimpan pesan
$pesan = "";

// Tambah data teman
if (isset($_POST['tambah'])) {
    $nim = $_POST['nim'];
    $nama = $_POST['nama'];
    $panggilan = $_POST['panggilan'];
    $prodi = $_POST['prodi'];

    // Query untuk menambah data
    $sql = "INSERT INTO tmn (nim, nama, panggilan, prodi) VALUES ('$nim', '$nama', '$panggilan', '$prodi')";
    if (mysqli_query($koneksi, $sql)) {
        $pesan = "Teman berhasil ditambahkan!";
        header("Location: teman.php"); 
        exit;
    } else {
        $pesan = "Error: " . mysqli_error($koneksi);
    }
}

// Hapus data teman
if (isset($_GET['hapus'])) {
    $nim = $_GET['hapus'];
    $sql = "DELETE FROM tmn WHERE nim = '$nim'";
    if (mysqli_query($koneksi, $sql)) {
        $pesan = "Teman berhasil dihapus!";
        header("Location: teman.php"); // Redirect setelah penghapusan
        exit;
    } else {
        $pesan = "Error: " . mysqli_error($koneksi);
    }
}

// Ubah data teman
if (isset($_POST['ubah'])) {
    $nim = $_POST['nim'];
    $nama = $_POST['nama'];
    $panggilan = $_POST['panggilan'];
    $prodi = $_POST['prodi'];

    // Query untuk mengubah data
    $sql = "UPDATE tmn SET nama = '$nama', panggilan = '$panggilan', prodi = '$prodi' WHERE nim = '$nim'";
    if (mysqli_query($koneksi, $sql)) {
        $pesan = "Teman berhasil diubah!";
        header("Location: teman.php"); // Redirect setelah pengubahan
        exit;
    } else {
        $pesan = "Error: " . mysqli_error($koneksi);
    }
}

// Ambil data teman dari database
$sql = "SELECT * FROM tmn";
$hasil = mysqli_query($koneksi, $sql);
?>

<div class="container">
    <h1 class="text-center">Daftar Teman</h1>
    <?php if ($pesan): ?>
        <div class="alert alert-info"><?= $pesan ?></div>
    <?php endif; ?>

    <!-- Form Tambah/Ubah Teman -->
    <form method="POST">
        <input type="hidden" name="nim" value="<?= isset($_GET['ubah']) ? $_GET['ubah'] : '' ?>">
        <div class="form-group">
            <label>NIM</label>
            <input type="text" name="nim" class="form-control" value="<?= isset($_GET['nim']) ? $_GET['nim'] : '' ?>" required>
        </div>
        <div class="form-group">
            <label>Nama</label>
            <input type="text" name="nama" class="form-control" value="<?= isset($_GET['nama']) ? $_GET['nama'] : '' ?>" required>
        </div>
        <div class="form-group">
            <label>Panggilan</label>
            <input type="text" name="panggilan" class="form-control" value="<?= isset($_GET['panggilan']) ? $_GET['panggilan'] : '' ?>" required>
        </div>
        <div class="form-group">
            <label>Prodi</label>
            <input type="text" name="prodi" class="form-control" value="<?= isset($_GET['prodi']) ? $_GET['prodi'] : '' ?>" required>
        </div>

        <?php if (isset($_GET['ubah'])): ?>
            <button type="submit" name="ubah" class="btn btn-warning">Ubah Teman</button>
        <?php else: ?>
            <button type="submit" name="tambah" class="btn btn-primary">Tambah Teman</button>
        <?php endif; ?>
    </form>

    <!-- Tabel Teman -->
    <table class="table table-bordered mt-5">
        <thead>
            <tr>
                <th>NIM</th>
                <th>Nama</th>
                <th>Panggilan</th>
                <th>Prodi</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
        <?php while ($row = mysqli_fetch_assoc($hasil)): ?>
            <tr>
                <td><?= $row['nim'] ?></td>
                <td><?= $row['nama'] ?></td>
                <td><?= $row['panggilan'] ?></td>
                <td><?= $row['prodi'] ?></td>
                <td>
                    <a href="teman.php?ubah=<?= $row['nim'] ?>&nim=<?= $row['nim'] ?>&nama=<?= $row['nama'] ?>&panggilan=<?= $row['panggilan'] ?>&prodi=<?= $row['prodi'] ?>" class="btn btn-warning btn-sm">Ubah</a>
                    <a href="teman.php?hapus=<?= $row['nim'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Yakin ingin menghapus?')">Hapus</a>
                </td>
            </tr>
        <?php endwhile; ?>
        </tbody>
    </table>
</div>

<script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-Fy6S3B9q64WdZWQUiU+q4/2Lc9npb8tCaSX9FK7E8HnRr0Jz8D6OP9dO5Vg3Q9ct" crossorigin="anonymous"></script>

</body>
</html>