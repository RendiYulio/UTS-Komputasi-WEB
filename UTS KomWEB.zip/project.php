<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Rendi Yulio Pramudita</title>

<style>
body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background: rgb(0,0,0);
    background: linear-gradient(90deg, rgba(0,0,0,1) 43%, rgba(226,73,78,1) 100%);
}

nav {
    background-color: #121414;
    padding: 15px 0;
    text-align: center;
}

nav a {
    margin: 0 15px;
    color: #ece3d8;
    text-decoration: none;
    font-size: 1.1em;
}

nav a:hover {
    color: #909984;
}

.container {
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 50px;
}

.text-section {
    flex: 2;
    text-align: center;
}

.image-section {
    margin-top: 30px;
    display: flex;
    justify-content: space-around;
    width: 100%;
}

figure {
    text-align: center;
    max-width: 20%;
}

figure img {
    width: 100%;
    height: auto;
    border-radius: 10px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
}

figcaption {
    margin-top: 10px;
    font-size: 0.9em;
    color: #ffffff;
}

 h1 {
    font-family: 'Abril Fatface', serif;
    font-weight: bold;
    font-size: 2.2em;
    color: #ffffff;
    margin-top: 00;
}

p {
    font-size: 0.9em;
    color: #ffffff;
    margin: 10px 0;
    text-align: center;
}
</style>

</head>
<body>
    <nav>
        <a href="home.php">Home</a>
        <a href="about.php">About</a>
        <a href="project.php">Project</a>
        <a href="skl.php">Skills</a>
        <a href="teman.php">Daftra Teman</a>
    </nav>
    
    <div class="container">
        <div class="text-section">
            <?php
            include("koneksi.php");
            // Query untuk mengambil data dari tabel "about_db"
            $sql = "SELECT * FROM pro";
            $hasil = mysqli_query($koneksi, $sql);

            // Cek apakah query berhasil
            if (!$hasil) {
                die("Query gagal: " . mysqli_error($koneksi));
            }

            // Cek apakah ada data
            if (mysqli_num_rows($hasil) > 0) {
                $row = mysqli_fetch_assoc($hasil); // Ambil data baris pertama jika ada
            } else {
                $row = []; // Jika tidak ada data, set array kosong
            }

            
            mysqli_close($koneksi);
            ?>

            <h1><?= isset($row["judul"]) ? $row["judul"] : ''; ?></h1>
            <p><?= isset($row["despro"]) ? $row["despro"] : ''; ?></p>
        </div>

        
        <div class="image-section">
            <figure>
                <img src="tk.png" alt="TK Putra Pertiwi" class="tk-image">
                <figcaption><?= isset($row["sub1"]) ? $row["sub1"] : ''; ?></figcaption>
            </figure>
            <figure>
                <img src="poster.png" alt="Aplikasi Makanan" class="poster-image">
                <figcaption><?= isset($row["sub2"]) ? $row["sub2"] : ''; ?></figcaption>
            </figure>
        </div>
    </div>
</body>
</html>